package model;

public class Breed {
	private int breed_id;
	private String breed_name;
	public Breed(int breed_id, String breed_name) {
		super();
		this.breed_id = breed_id;
		this.breed_name = breed_name;
	}
	public int getBreed_id() {
		return breed_id;
	}
	public void setBreed_id(int breed_id) {
		this.breed_id = breed_id;
	}
	public String getBreed_name() {
		return breed_name;
	}
	public void setBreed_name(String breed_name) {
		this.breed_name = breed_name;
	}
	
	
	

}
