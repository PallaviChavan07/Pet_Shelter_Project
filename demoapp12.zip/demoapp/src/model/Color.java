package model;

public class Color {
	
	private String colorname;

	public Color() {
		
	}

	public Color(String colorname) {
		super();
		this.colorname = colorname;
	}

	public String getColorname() {
		return colorname;
	}

	public void setColorname(String colorname) {
		this.colorname = colorname;
	}
	
	

}
